import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    allowedHosts: true,
    port: 5173,
    proxy: { '/api': { target: process.env.VITE_API || 'http://localhost:8080', changeOrigin: true } }
  }
})
